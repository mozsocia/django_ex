from django import forms


class RawProductForm(forms.Form):
    title = forms.CharField(label="Title", required=True,
                            widget=forms.TextInput())
    
    description = forms.CharField(
        required=True, widget=forms.Textarea(
            attrs={
                "class": "form-control",
                "id": "my-form-id",
                "rows": 10,
                "cols" : 20
            }
        )
    )
    
    user_dob = forms.DateField(
        label="Date of Birth", widget=forms. TextInput(attrs={'type': 'date'}))

    user_email = forms. EmailField(label="Email", widget=forms.TextInput(
        attrs={'placeholder': 'Enter your Email Address', }))

    boolean_field = forms.BooleanField(required=False)

    field = forms.ChoiceField(
        choices=(('1', 'First'), ('2', 'Second'), ('3', 'Third')))

    choices = (('', '--SELECT OPTION--'), ('1', 'First'),
               ('2', 'Second'), ('3', 'Third'))
    field22 = forms.ChoiceField(choices=choices)

    choices = (('A', 'A'), ('B', 'B'), ('C', 'C'))
    field33 = forms.ChoiceField(choices=choices, widget=forms.RadioSelect)

    choices = (('', '--SELECT OPTION--'), ('1', 'First'),
               ('2', 'Second'), ('3', 'Third'))
    field44 = forms.MultipleChoiceField(choices=choices, required=False)

    choices = (('A', 'A'), ('B', 'B'), ('C', 'C'))
    field55 = forms. MultipleChoiceField(
        choices=choices, widget=forms.CheckboxSelectMultiple)
