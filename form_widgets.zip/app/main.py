from django.forms.models import model_to_dict
from django.forms.widgets import TextInput
from django.urls import path
from django.http.response import HttpResponse, JsonResponse
from django.shortcuts import render
from django.db import models
from app.forms import *
from app.f_choise_queryset import *

def index(request):
    return HttpResponse("all")

def form_fn(request):
    newform = RawProductForm()
    contxt= {"l_form": newform}
    return render(request, 'index.html', contxt)

def form_fn2(request):
    print(Choice.objects.all())
    newform = ContactForm()
    contxt= {"l_form": newform}
    return render(request, 'index.html', contxt)

def create_fn(request):
    Choice.objects.create(choice_text="dfskjadskf one" , aaa="aaa one", bbb="bbb one" , ccc="cccc one", ddd="ddd one")
    Choice.objects.create(choice_text="dfskjadskf two" , aaa="aaa two", bbb="bbb two" , ccc="cccc two", ddd="ddd two")
    Choice.objects.create(choice_text="dfskjadskf three" , aaa="aaa three", bbb="bbb three" , ccc="cccc three", ddd="ddd three")
    Choice.objects.create(choice_text="dfskjadskf four" , aaa="aaa four", bbb="bbb four" , ccc="cccc four", ddd="ddd four")
    
    return HttpResponse("done")

urlpatterns = [
    path('home/', index),
    path('form/',form_fn),
    path('form2/', form_fn2),
    path('create/', create_fn)
]