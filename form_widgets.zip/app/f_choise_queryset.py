from django.db import models
from django import forms

class Choice(models.Model):
    choice_text = models.CharField(max_length=100)
    aaa = models.CharField(max_length=200)
    bbb = models.CharField(max_length=200)
    ccc = models.CharField(max_length=200)
    ddd = models.CharField(max_length=200)
    def __str__(self):
        return self.choice_text



class Contatto(models.Model):
    contatto_choice =  models.ForeignKey(Choice, on_delete=models.PROTECT)
    phone_number = models.CharField(max_length=12)
    email = models.CharField(max_length=100)
    name = models.CharField(max_length=250)
    def __str__(self):
        return self.email
    
    
class ContactForm(forms.ModelForm):    
    contatto_choice = forms.ModelChoiceField(queryset=Choice.objects.filter(id__in=[1, 3, 4]),widget=forms.RadioSelect)
    class Meta:
        model = Contatto
        fields = ['contatto_choice', 'phone_number','email','name']